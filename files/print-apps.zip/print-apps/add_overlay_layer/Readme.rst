This example demonstrates how to use the BackgroundLayerProcessor to declare background layers in the configuration file that will be added below
the layers sent by the client.